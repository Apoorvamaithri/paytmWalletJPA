package com.cg.plp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customer")
public class Customer {
	
	@Column(name = "cust_name")
	private String name;
	
	@Id
	@Column(name = "cust_contactno")
	private String contactNo;
	
	@Column(name = "cust_age")
	private float age;
	
	@Column(name = "cust_initialBal")
	private double initialBalance;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}
	
	public double getInitialBalance() {
		return initialBalance;
	}
	public void setInitialBalance(double initialBalance) {
		this.initialBalance = initialBalance;
	}
	public Customer(String name, String contactNo, float age, double initialBalance) {
		this.name = name;
		this.contactNo = contactNo;
		this.age = age;
		this.initialBalance = initialBalance;
	}
	public Customer() {
		super();
	}
}
