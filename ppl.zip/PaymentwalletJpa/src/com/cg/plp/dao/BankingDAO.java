package com.cg.plp.dao;

import java.util.List;

import com.cg.plp.dto.Customer;
import com.cg.plp.dto.Transactions;
import com.cg.plp.exception.BankAccountException;

public interface BankingDAO {

	public void createAccount(Customer customer);
	
	public void deposit(String contactNo, double amount);
	
	public void withdraw(String contactNo, double amount);
	
	public double checkBalance(String contactNo);
	
	public void fundTransfer(String sender, String reciever, double amount);
	
	public boolean validateAccount(String contactNo) throws BankAccountException;
	
	public void passbookD(Customer customer, double amount);

	void passbookW(Customer customer, double amount);

	void passbookF(Customer customer1, Customer customer2, double amount);

	public List<Transactions> getTransList(String mobileNo);
	
	//public List<Transactions> getTransList(String contactNo);
	
}
